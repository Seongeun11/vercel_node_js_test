module.exports = (req, res) => {
  res.status(200).send('Vercel에서 Node.js 서버 작동 중!');
};