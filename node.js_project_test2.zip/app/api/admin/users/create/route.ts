// app/api/admin/users/create/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { requireRole } from '@/lib/serverAuth'
import { supabaseAdmin } from '@/lib/supabase/admin'
import { studentIdToEmail } from '@/lib/auth-email'

type Body = {
  student_id: string
  password: string
  full_name: string
  role: 'admin' | 'captain' | 'trainee'
}

export async function POST(request: NextRequest) {
  try {
    const authResult = await requireRole(['admin'])

    if (!authResult.ok || !authResult.user) {
      return NextResponse.json(
        { error: authResult.error },
        { status: authResult.status }
      )
    }

    const body = (await request.json()) as Body
    const studentId = String(body.student_id || '').trim()
    const password = String(body.password || '').trim()
    const fullName = String(body.full_name || '').trim()
    const role = body.role

    if (!studentId || !password || !fullName || !role) {
      return NextResponse.json(
        { error: '필수값이 누락되었습니다.' },
        { status: 400 }
      )
    }

    const email = studentIdToEmail(studentId)

    const { data: createdAuth, error: createAuthError } =
      await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
      })

    if (createAuthError || !createdAuth.user) {
      return NextResponse.json(
        { error: createAuthError?.message || '사용자 생성 실패' },
        { status: 400 }
      )
    }

    const { error: profileError } = await supabaseAdmin.from('profiles').insert({
      id: createdAuth.user.id,
      student_id: studentId,
      full_name: fullName,
      role,
    })

    if (profileError) {
      await supabaseAdmin.auth.admin.deleteUser(createdAuth.user.id)

      return NextResponse.json(
        { error: profileError.message },
        { status: 400 }
      )
    }

    return NextResponse.json({
      ok: true,
      user: {
        id: createdAuth.user.id,
        student_id: studentId,
        full_name: fullName,
        role,
      },
    })
  } catch (error) {
    console.error(error)
    return NextResponse.json({ error: '서버 오류' }, { status: 500 })
  }
}